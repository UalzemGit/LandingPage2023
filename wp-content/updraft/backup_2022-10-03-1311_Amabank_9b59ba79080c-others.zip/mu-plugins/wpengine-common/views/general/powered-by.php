<?php
/**
 * Powered by
 *
 * @package wpengine/common-mu-plugin
 */

?>
Powered by <a href="<?php echo esc_url( $affiliate_link ? $affiliate_link : 'https://wpengine.com' ); ?>" title="<?php esc_attr_e( 'Managed WordPress Hosting', 'wpengine' ); ?>" target="_blank"><img style="width: 100px;" src="<?php echo esc_url( $logo ); ?>"></a>
