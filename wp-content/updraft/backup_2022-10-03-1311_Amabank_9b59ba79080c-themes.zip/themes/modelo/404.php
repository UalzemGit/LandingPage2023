<script>
window.location.href = "<?php echo site_url();?>";
</script>